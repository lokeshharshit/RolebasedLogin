﻿using System.ComponentModel.DataAnnotations.Schema;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;
using System.ComponentModel.DataAnnotations;



namespace Users.Models
{
    public class RoleName
    {
        [Key]
        public int Id { get; set; }
        public string? Role { get; set; }
        public string? Permissions { get; set; }
    }
}
