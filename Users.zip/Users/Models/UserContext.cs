﻿using Microsoft.EntityFrameworkCore;

namespace Users.Models
{
    public class UserContext :DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base(options)
        {
            
        }
        public DbSet<User> Users { get; set; }
        public DbSet<RoleName> Roles { get; set; }
    }
}
