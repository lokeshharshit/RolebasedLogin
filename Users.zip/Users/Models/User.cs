﻿using MessagePack;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;

namespace Users.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] 
        public int Id { get; set; }

        [StringLength(150)]
        public string? Name { get; set; }
        [StringLength(250)]
        public string? Email { get; set; }
        [StringLength(150)]
        public string? Password { get; set; }
        public int?  RoleID{ get; set; }

        [NotMapped]
        public string? Role { get; set; }

    }
}
