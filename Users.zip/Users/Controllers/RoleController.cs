﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Users.Models;

namespace Users.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly UserContext _context;

        public RoleController(UserContext context)
        {
            _context = context;
        }

        // GET: api/Role
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RoleName>>> GetRoles()
        {
          if (_context.Roles == null)
          {
              return NotFound();
          }
            return await _context.Roles.ToListAsync();
        }

        // GET: api/Role/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RoleName>> GetRoleName(int id)
        {
          if (_context.Roles == null)
          {
              return NotFound();
          }
            var roleName = await _context.Roles.FindAsync(id);

            if (roleName == null)
            {
                return NotFound();
            }

            return roleName;
        }

        // PUT: api/Role/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRoleName(int id, RoleName roleName)
        {
            if (id != roleName.Id)
            {
                return BadRequest();
            }

            _context.Entry(roleName).State = EntityState.Modified;
            
            try
            {
                
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RoleNameExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Role
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<RoleName>> PostRoleName(RoleName roleName)
        {
          if (_context.Roles == null)
          {
              return Problem("Entity set 'UserContext.Roles'  is null.");
          }
            _context.Roles.Add(roleName);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRoleName", new { id = roleName.Id }, roleName);
        }

        // DELETE: api/Role/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoleName(int id)
        {
            if (_context.Roles == null)
            {
                return NotFound();
            }
            var roleName = await _context.Roles.FindAsync(id);
            if (roleName == null)
            {
                return NotFound();
            }

            _context.Roles.Remove(roleName);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RoleNameExists(int id)
        {
            return (_context.Roles?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
